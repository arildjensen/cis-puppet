cis-puppet
====================

Center for Internet Security Linux Benchmark implementation for Puppet.
